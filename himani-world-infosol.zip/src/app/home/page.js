import React from 'react'
import ClientLayout from '../Clientlayout'

const page = () => {
  return (
    <ClientLayout>page</ClientLayout>
  )
}

export default page